import streamlit as st
import pandas as pd
import plotly.express as px

# File path for logs
log_file = "C:/Users/aishw/OneDrive/Desktop/STOCK PRICE Prediction/Final_Files/predictions_log.csv"

st.set_page_config(layout="wide", page_title="Stock Price Prediction Dashboard")
st.title("Real-Time Stock Price Prediction Dashboard")

# Load data
@st.cache_data
def load_data():
    return pd.read_csv(log_file)

df = load_data()

# Show latest predictions
st.subheader("Latest Stock Predictions")
st.dataframe(df.tail(10), height=250)

# --- Performance Metrics ---
st.subheader("Model Performance Metrics")
col1, col2, col3 = st.columns(3)
col1.metric("Mean Squared Error (MSE)", round(df["MSE"].mean(), 4))
col2.metric("Mean Absolute Percentage Error (MAPE)", round(df["MAPE"].mean(), 4))
col3.metric("Average Latency (sec)", round(df["Latency"].mean(), 4))

# --- Predicted vs Actual Prices ---
st.subheader("Predicted vs Actual Closing Prices")

df["Timestamp"] = pd.to_datetime(df["Timestamp"], errors='coerce')
df = df.dropna(subset=["Timestamp"]).sort_values(by="Timestamp")

tickers = df["Ticker"].unique()
for ticker in tickers:
    st.subheader(f"{ticker} - Predicted vs Actual Prices")
    ticker_df = df[df["Ticker"] == ticker]
    if not ticker_df.empty:
        fig_price = px.line(ticker_df, x="Timestamp", y=["Predicted_Close", "Actual_Close"],
                             title=f"{ticker} - Predicted vs Actual Prices")
        st.plotly_chart(fig_price, use_container_width=True)
    else:
        st.warning(f"No data available for {ticker}.")

st.write("Data updates automatically. Refresh the page to see the latest predictions.")
