import yfinance as yf
import pandas as pd

# List of stock tickers (S&P 500 or any other list of stocks you want)
# You can modify this list to include more stocks
SP500_TICKERS = ["AAPL", "MSFT", "GOOGL", "AMZN", "TSLA", "META", "NVDA", "BRK-B", "JPM", "V"]

def fetch_stock_data_multiple(tickers):
    """
    Fetch last 5 years of daily stock data (Open, High, Low, Close) for multiple stocks
    and save them to a single CSV file.
    """
    all_data = []
    
    for ticker in tickers:
        print(f"Fetching data for {ticker}...")
        try:
            stock = yf.Ticker(ticker)
            data = stock.history(period="5y")
            if data.empty:
                print(f"No data found for {ticker}, skipping...")
                continue
            
            # Select required columns: Open, High, Low, Close
            data = data[['Open', 'High', 'Low', 'Close']]
            data = data.reset_index()
            data["Ticker"] = ticker  # Add ticker column
            all_data.append(data)
        except Exception as e:
            print(f"Error fetching data for {ticker}: {e}")
    
    # Combine all stock data
    if all_data:
        final_data = pd.concat(all_data, ignore_index=True)
        final_data.to_csv("all_stock_prices5Y.csv", index=False)
        print("Stock data for multiple stocks saved to all_stock_prices5Y.csv")
    else:
        print("No data fetched for any stocks.")

if __name__ == "__main__":
    fetch_stock_data_multiple(SP500_TICKERS)
