import yfinance as yf
import time
import json
from kafka import KafkaProducer

# Stock tickers to fetch
TICKERS = ["AAPL", "MSFT", "GOOGL", "AMZN", "TSLA"]

# Kafka Config
KAFKA_TOPIC = "stock_prices"
KAFKA_BROKER = "localhost:9092"

# Initialize Kafka Producer
producer = KafkaProducer(
    bootstrap_servers=KAFKA_BROKER,
    value_serializer=lambda v: json.dumps(v, default=str).encode("utf-8")
)

def fetch_realtime_stock_data():
    """Fetch real-time stock data and send it to Kafka."""
    data_list = []
    for ticker in TICKERS:
        stock = yf.Ticker(ticker)
        data = stock.history(period="1d", interval="1m")  # 1-minute interval
        if not data.empty:
            latest = data.iloc[-1]
            stock_data = {
                "Ticker": ticker,
                "Timestamp": latest.name.strftime("%Y-%m-%d %H:%M:%S"),
                "Open": latest["Open"],
                "High": latest["High"],
                "Low": latest["Low"],
                "Close": latest["Close"]
            }
            data_list.append(stock_data)

    if data_list:
        producer.send(KAFKA_TOPIC, value={"data": data_list})
        producer.flush()
        print(f"Sent {len(data_list)} stock price updates to Kafka.")

if __name__ == "__main__":
    print("Streaming real-time stock prices to Kafka...")
    try:
        while True:
            fetch_realtime_stock_data()
            time.sleep(10)  # Reduce sleep time for faster updates
    except KeyboardInterrupt:
        print("Stopping the producer.")
    finally:
        producer.close()
