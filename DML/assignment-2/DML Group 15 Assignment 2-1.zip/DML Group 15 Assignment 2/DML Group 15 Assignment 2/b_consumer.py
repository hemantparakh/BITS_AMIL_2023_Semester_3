import torch
import torch.nn as nn
import json
import time
import datetime
import os
import pandas as pd
from kafka import KafkaConsumer, KafkaProducer
from sklearn.metrics import mean_squared_error, mean_absolute_percentage_error

# ---------------------------
# LSTM Model Definition
# ---------------------------
class LSTMStockPredictor(nn.Module):
    def __init__(self, input_size, hidden_size=64, num_layers=2):
        super(LSTMStockPredictor, self).__init__()
        self.hidden_size = hidden_size
        self.num_layers = num_layers
        self.lstm = nn.LSTM(input_size, hidden_size, num_layers, batch_first=True)
        self.fc = nn.Linear(hidden_size, 1)
    
    def forward(self, x):
        h0 = torch.zeros(self.num_layers, x.size(0), self.hidden_size).to(x.device)
        c0 = torch.zeros(self.num_layers, x.size(0), self.hidden_size).to(x.device)
        out, _ = self.lstm(x, (h0, c0))
        return self.fc(out[:, -1, :])

# Load LSTM Model
input_size = 1
window_size = 50
model_path = "C:/Users/aishw/OneDrive/Desktop/STOCK PRICE Prediction/Final_Files/lstm_stock_model.pth"
lstm_model = LSTMStockPredictor(input_size)
lstm_model.load_state_dict(torch.load(model_path))
lstm_model.eval()
print("LSTM Model loaded successfully in Consumer!")

# ---------------------------
# Kafka Configurations
# ---------------------------
KAFKA_INPUT_TOPIC = "stock_prices"
KAFKA_OUTPUT_TOPIC = "predictions"
KAFKA_BROKER = "localhost:9092"

# Initialize Kafka Consumer
consumer = KafkaConsumer(
    KAFKA_INPUT_TOPIC,
    bootstrap_servers=KAFKA_BROKER,
    value_deserializer=lambda x: json.loads(x.decode("utf-8"))
)

# Initialize Kafka Producer
producer = KafkaProducer(
    bootstrap_servers=KAFKA_BROKER,
    value_serializer=lambda v: json.dumps(v).encode("utf-8")
)

print("Consumer is running... Waiting for real-time data from Kafka...")

recent_prices = {}  # Stores last `window_size` prices per ticker
log_file = "C:/Users/aishw/OneDrive/Desktop/STOCK PRICE Prediction/Final_Files/predictions_log.csv"

def process_stock_data(stock_data):
    global recent_prices
    ticker = stock_data["Ticker"]
    close_price = stock_data["Close"]
    timestamp = stock_data["Timestamp"]

    if ticker not in recent_prices:
        recent_prices[ticker] = []

    # Append closing price for ticker
    recent_prices[ticker].append(close_price)

    # Keep only last 50 prices
    if len(recent_prices[ticker]) > window_size:
        recent_prices[ticker].pop(0)

    if len(recent_prices[ticker]) < window_size:
        print(f"Not enough records for {ticker}. Waiting for {window_size - len(recent_prices[ticker])} more entries...")
        return

    start_time = time.time()

    # Prepare LSTM input
    X_lstm = torch.tensor(recent_prices[ticker], dtype=torch.float32).view(1, window_size, 1)

    # Predict next price
    with torch.no_grad():
        predicted_price = lstm_model(X_lstm).item()

    mse = mean_squared_error([close_price], [predicted_price])
    mape = mean_absolute_percentage_error([close_price], [predicted_price])
    latency = time.time() - start_time

    log_entry = {
        "Ticker": ticker,
        "Timestamp": timestamp,
        "Predicted_Close": predicted_price,
        "Actual_Close": close_price,
        "MSE": mse,
        "MAPE": mape,
        "Latency": latency,
        "Processed_At": str(datetime.datetime.now())
    }

    save_to_csv(log_entry)
    
    producer.send(KAFKA_OUTPUT_TOPIC, value=log_entry)
    producer.flush()

    print(f"{ticker} -> Predicted: {predicted_price:.2f}, Actual: {close_price:.2f}, MSE: {mse:.4f}, MAPE: {mape:.4f}, Latency: {latency:.4f} sec")

def save_to_csv(log_entry):
    file_exists = os.path.exists(log_file)
    df_entry = pd.DataFrame([log_entry])
    if file_exists:
        df_entry.to_csv(log_file, mode="a", header=False, index=False)
    else:
        df_entry.to_csv(log_file, mode="w", header=True, index=False)

for message in consumer:
    stock_data_list = message.value.get("data", [])
    for stock_data in stock_data_list:
        process_stock_data(stock_data)
