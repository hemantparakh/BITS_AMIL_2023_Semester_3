import torch
import torch.nn as nn
import torch.optim as optim
import pandas as pd

# ---------------------------
# LSTM Model Definition
# ---------------------------
class LSTMStockPredictor(nn.Module):
    def __init__(self, input_size, hidden_size=64, num_layers=2):
        super(LSTMStockPredictor, self).__init__()
        self.hidden_size = hidden_size
        self.num_layers = num_layers
        
        # LSTM layers
        self.lstm = nn.LSTM(input_size, hidden_size, num_layers, batch_first=True)
        
        # Fully connected layer
        self.fc = nn.Linear(hidden_size, 1)

    def forward(self, x):
        h0 = torch.zeros(self.num_layers, x.size(0), self.hidden_size).to(x.device)
        c0 = torch.zeros(self.num_layers, x.size(0), self.hidden_size).to(x.device)
        
        out, _ = self.lstm(x, (h0, c0))
        out = self.fc(out[:, -1, :])  # Take the last output for prediction
        
        return out

# ---------------------------
# Load Dataset
# ---------------------------
file_path = r"C:\Users\aishw\OneDrive\Desktop\STOCK PRICE Prediction\Final_Files\all_stock_prices5Y.csv"
df = pd.read_csv(file_path)

df["Date"] = pd.to_datetime(df["Date"], utc=True)
df["Days"] = (df["Date"] - df["Date"].min()).dt.days

df = df[["Days", "Close"]].rename(columns={"Close": "Price"})

# ---------------------------
# Create Training Samples using a Sliding Window
# ---------------------------
window_size = 50  # Use last 50 days to predict the next day's price
X_list = []
y_list = []
N = len(df)

for i in range(N - window_size):
    window = df["Price"].iloc[i:i+window_size].values
    target = df["Price"].iloc[i + window_size]
    X_list.append(window)
    y_list.append(target)

X_train = torch.tensor(X_list, dtype=torch.float32).view(-1, window_size, 1)
y_train = torch.tensor(y_list, dtype=torch.float32).view(-1, 1)

print(f"Prepared training data: X_train shape: {X_train.shape}, y_train shape: {y_train.shape}")

# ---------------------------
# Model Training
# ---------------------------
input_size = 1  # One feature: 'Price'
hidden_size = 64
num_layers = 2
batch_size = 32
epochs = 100

# Initialize model
model = LSTMStockPredictor(input_size, hidden_size, num_layers)
criterion = nn.MSELoss()
optimizer = optim.Adam(model.parameters(), lr=0.001)

# Training loop
for epoch in range(epochs):
    for i in range(0, len(X_train), batch_size):
        X_batch = X_train[i:i+batch_size]
        y_batch = y_train[i:i+batch_size]
        
        optimizer.zero_grad()
        outputs = model(X_batch)
        loss = criterion(outputs, y_batch)
        loss.backward()
        optimizer.step()

    if epoch % 10 == 0:
        print(f"Epoch [{epoch}/{epochs}], Loss: {loss.item():.4f}")

# ---------------------------
# Save the Trained Model
# ---------------------------
torch.save(model.state_dict(), "lstm_stock_model.pth")
print("Model training complete. Saved as 'lstm_stock_model.pth'.")
