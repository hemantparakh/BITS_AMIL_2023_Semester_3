"""python -m pip uninstall kafka-python -y
python -m pip uninstall torch -y
python -m pip uninstall pandas -y

python -m pip install kafka-python
python -m pip install torch
python -m pip install pandas"""

import sys
import torch
import torch.nn as nn
import pandas as pd
import json
from kafka import KafkaConsumer, KafkaProducer

print("Python executable:", sys.executable)
print("Python version:", sys.version)
print("torch version:", torch.__version__)
print("pandas version:", pd.__version__)
print("KafkaConsumer and KafkaProducer imported successfully!")

