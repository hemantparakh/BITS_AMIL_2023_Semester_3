import torch
import torch.nn as nn
import torch.optim as optim
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score
from sklearn.model_selection import train_test_split

# ---------------------------
# LSTM Model Definition
# ---------------------------
class LSTMStockPredictor(nn.Module):
    def __init__(self, input_size, hidden_size=64, num_layers=2):
        super(LSTMStockPredictor, self).__init__()
        self.hidden_size = hidden_size
        self.num_layers = num_layers
        self.lstm = nn.LSTM(input_size, hidden_size, num_layers, batch_first=True)
        self.fc = nn.Linear(hidden_size, 1)

    def forward(self, x):
        h0 = torch.zeros(self.num_layers, x.size(0), self.hidden_size).to(x.device)
        c0 = torch.zeros(self.num_layers, x.size(0), self.hidden_size).to(x.device)
        out, _ = self.lstm(x, (h0, c0))
        out = self.fc(out[:, -1, :])  # Take the last output for prediction
        return out

# ---------------------------
# Load Dataset
# ---------------------------
file_path = r"C:\Users\aishw\OneDrive\Desktop\STOCK PRICE Prediction\Final_Files\all_stock_prices5Y.csv"
df = pd.read_csv(file_path)

df["Date"] = pd.to_datetime(df["Date"], utc=True)
df["Days"] = (df["Date"] - df["Date"].min()).dt.days
df = df[["Days", "Close"]].rename(columns={"Close": "Price"})

# ---------------------------
# Create Training & Testing Samples using Sliding Window
# ---------------------------
window_size = 50  
X_list, y_list = [], []
N = len(df)

for i in range(N - window_size):
    X_list.append(df["Price"].iloc[i:i+window_size].values)
    y_list.append(df["Price"].iloc[i + window_size])

X = np.array(X_list).reshape(-1, window_size, 1)
y = np.array(y_list).reshape(-1, 1)

# Split into training (80%) and testing (20%)
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, shuffle=False)

X_train = torch.tensor(X_train, dtype=torch.float32)
y_train = torch.tensor(y_train, dtype=torch.float32)
X_test = torch.tensor(X_test, dtype=torch.float32)
y_test = torch.tensor(y_test, dtype=torch.float32)

print(f"Training data: X_train: {X_train.shape}, y_train: {y_train.shape}")
print(f"Testing data: X_test: {X_test.shape}, y_test: {y_test.shape}")

# ---------------------------
# Model Training
# ---------------------------
input_size = 1  
hidden_size = 64
num_layers = 2
batch_size = 32
epochs = 100

# Initialize model
model = LSTMStockPredictor(input_size, hidden_size, num_layers)
criterion = nn.MSELoss()
optimizer = optim.Adam(model.parameters(), lr=0.001)

train_losses = []
test_losses = []

# Training loop
for epoch in range(epochs):
    model.train()
    epoch_loss = 0
    
    for i in range(0, len(X_train), batch_size):
        X_batch = X_train[i:i+batch_size]
        y_batch = y_train[i:i+batch_size]
        
        optimizer.zero_grad()
        outputs = model(X_batch)
        loss = criterion(outputs, y_batch)
        loss.backward()
        optimizer.step()
        
        epoch_loss += loss.item()
    
    train_losses.append(epoch_loss / len(X_train))
    
    # Validation loss calculation
    model.eval()
    with torch.no_grad():
        test_outputs = model(X_test)
        test_loss = criterion(test_outputs, y_test).item()
        test_losses.append(test_loss)
    
    if epoch % 10 == 0:
        print(f"Epoch [{epoch}/{epochs}], Train Loss: {train_losses[-1]:.4f}, Test Loss: {test_loss:.4f}")

# ---------------------------
# Save the Trained Model
# ---------------------------
torch.save(model.state_dict(), "lstm_stock_model.pth")
print("Model training complete. Saved as 'lstm_stock_model.pth'.")

# ---------------------------
# Model Evaluation
# ---------------------------
model.eval()
with torch.no_grad():
    predicted = model(X_test).numpy()
    
mae = mean_absolute_error(y_test.numpy(), predicted)
rmse = np.sqrt(mean_squared_error(y_test.numpy(), predicted))
r2 = r2_score(y_test.numpy(), predicted)

print(f"Model Evaluation Metrics:")
print(f"MAE: {mae:.4f}")
print(f"RMSE: {rmse:.4f}")
print(f"R² Score: {r2:.4f}")

# ---------------------------
# Loss Visualization
# ---------------------------
plt.figure(figsize=(10, 5))
plt.plot(train_losses, label="Train Loss")
plt.plot(test_losses, label="Test Loss")
plt.xlabel("Epochs")
plt.ylabel("Loss")
plt.title("Training & Testing Loss over Epochs")
plt.legend()
plt.savefig("loss_plot.png")  # Save the plot
plt.show()

# ---------------------------
# Prediction vs Actual Visualization
# ---------------------------
plt.figure(figsize=(12, 6))
plt.plot(y_test.numpy(), label="Actual Prices", color='blue')
plt.plot(predicted, label="Predicted Prices", linestyle="dashed", color='red')
plt.xlabel("Time Steps")
plt.ylabel("Stock Price")
plt.title("Stock Price Prediction vs Actual")
plt.legend()
plt.savefig("prediction_vs_actual.png")  # Save the plot
plt.show()
